│   ├── investment_allocation.csv      # 投资分配方案
│   ├── before_after_comparison.csv    # 投资前后对比
│   ├── dimension_distribution.csv     # 维度投资分布
│   └── topsis_improvement.csv         # TOPSIS得分变化